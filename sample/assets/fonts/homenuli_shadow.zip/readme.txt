NOTE: This demo font is FREE for PERSONAL USE ONLY! But any donation are very appreciated because your donation will help us to create more fonts.

If you want DONATE click here:
https://www.paypal.me/ekonurcahyo

For Commercial Rights please contact us: kotakkuningstudio@gmail.com

Check this out for other premium fonts at My Store:
https://creativemarket.com/kotakkuning
https://fontbundles.net/kotak-kuning-studio
https://www.creativefabrica.com/designer/kotak-kuning-studio/
https://graphicriver.net/user/kotakkuningstudio/portfolio

And follow my instagram for update: @kotakkuningstudio

Regards,
Kotak Kuning Studio